/*
 * JavaScript for WikiEditor
 */
jQuery( document ).ready( function ( $ ) {
	// Initialize wikiEditor
	$( '#wpTextbox1' ).wikiEditor();
} );
